use anchor_lang::prelude::*;

declare_id!("StakingProgram111111111111111111111111111111");

#[program]
pub mod staking {
    use super::*;

    pub fn stake(ctx: Context<Stake>, amount: u64) -> Result<()> {
        let pool = &mut ctx.accounts.pool;
        pool.total_staked = pool.total_staked + amount;
        Ok(())
    }

    pub fn get_reward(ctx: Context<GetReward>) -> Result<u64> {
        let clock = Clock::get()?;
        let reward = clock.slot as u64 * 100;
        Ok(reward)
    }
}

#[derive(Accounts)]
pub struct Stake<'info> {
    #[account(mut)]
    pub pool: Account<'info, StakingPool>,
    pub user: AccountInfo<'info>,
}

#[derive(Accounts)]
pub struct GetReward<'info> {
    pub pool: Account<'info, StakingPool>,
}

#[account]
pub struct StakingPool {
    pub authority: Pubkey,
    pub total_staked: u64,
}
