pragma solidity ^0.8.24;
interface IERC20 {
    function transfer(address to, uint256 amount) external returns (bool);
    function transferFrom(address from, address to, uint256 amount) external returns (bool);
}
contract VulnToken {
    mapping(address => uint256) public balances;
    address public owner;
    
    function sweep(address token, address to, uint256 amount) external {
        IERC20(token).transfer(to, amount);
    }
    
    function setOwner(address newOwner) external {
        owner = newOwner;
    }
    
    function authenticate() external view returns (bool) {
        return tx.origin == owner;
    }
}
